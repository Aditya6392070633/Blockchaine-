import {mkdirSync,writeFileSync} from 'node:fs';
import {resolve} from 'node:path';
import {createWallet,unlockWallet,signTransaction} from '../public/wallet.js';
const url=process.env.NODE_URL||'http://localhost:3000';
const password='SuCoin-demo-password-2026';
async function call(path,body){const r=await fetch(url+path,{method:body?'POST':'GET',headers:body?{'content-type':'application/json','x-node-token':token}:{},body:body?JSON.stringify(body):undefined});const data=await r.json();if(!r.ok)throw Error(data.error);return data;}
let token;
try {
 ({token}=await call('/api/session'));
 const a=await createWallet(password), b=await createWallet(password);
 const ak=await unlockWallet(a,password),bk=await unlockWallet(b,password);
 const dir=resolve('data','demo-wallets-'+Date.now());mkdirSync(dir,{recursive:true,mode:0o700});
 writeFileSync(resolve(dir,'seller.json'),JSON.stringify(a,null,2),{mode:0o600});writeFileSync(resolve(dir,'buyer.json'),JSON.stringify(b,null,2),{mode:0o600});
 await call('/api/mine',{address:a.address});
 await call('/api/transactions',await signTransaction(b,bk,1,'faucet',{}));
 await call('/api/transactions',await signTransaction(a,ak,1,'order',{side:'sell',quantity:10e6,price:2e6}));
 await call('/api/transactions',await signTransaction(b,bk,2,'order',{side:'buy',quantity:4e6,price:3e6}));
 await call('/api/mine',{address:a.address});
 console.log('Demo complete: mined SUC, issued test dollars, matched 4 SUC at 2 tUSD, left 6 SUC on the order book.');
 console.log('Import buyer.json or seller.json from: '+dir+'\nDemo-only password: '+password+'\nThese wallets are for testing only. Never use this password for anything valuable.');
} catch(e){console.error('Demo failed: '+e.message+'\nStart the node first with npm start.');process.exitCode=1;}
