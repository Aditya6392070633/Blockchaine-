import http from 'node:http';
import {randomBytes,timingSafeEqual} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {Chain,account,validAddress,NETWORK,SCALE,DIFFICULTY,reward} from './chain.js';
const root=resolve(dirname(fileURLToPath(import.meta.url)),'../public');
export function createNode({file=null, peers=[]}={}) {
  const chain=new Chain(file), token=randomBytes(32).toString('hex');
  const counts=new Map();
  function json(res,status,data) {res.writeHead(status,{'Content-Type':'application/json'});res.end(JSON.stringify(data));}
  const server=http.createServer(async(req,res)=>{
    res.setHeader('X-Content-Type-Options','nosniff'); res.setHeader('Cache-Control','no-store');
    res.setHeader('Referrer-Policy','no-referrer');
    res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; connect-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
    try {
      const host=req.headers.host || '';
      if(!/^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/.test(host)) return json(res,403,{error:'Use localhost or 127.0.0.1. This node is local-only.'});
      const url=new URL(req.url,'http://'+host), path=url.pathname;
      if(req.method==='GET') {
        if(path==='/api/session') return json(res,200,{token,network:NETWORK});
        if(path==='/api/chain') return json(res,200,{blocks:chain.blocks});
        if(path==='/api/state') {
          const a=url.searchParams.get('address');
          if(a && !validAddress(a)) throw new Error('Invalid address');
          const state=chain.state;
          return json(res,200,{network:NETWORK,height:chain.blocks.length-1,supply:state.supply,scale:SCALE,difficulty:DIFFICULTY,reward:reward(chain.blocks.length),
            pending:chain.pending,blocks:chain.blocks.slice(-30).reverse(),orders:state.orders,trades:state.trades.slice(-100),
            account:a ? account(structuredClone(state),a) : null,projected:a ? account(chain.overlay(),a) : null,
            activity:a ? chain.blocks.flatMap(b=>b.transactions.filter(t=>t.from===a||t.data.to===a).map(t=>({...t,height:b.height}))).slice(-100).reverse() : [],peers});
        }
        const files={'/':'index.html','/app.js':'app.js','/style.css':'style.css','/wallet.js':'wallet.js'};
        if(files[path]) {
          const mime=path.endsWith('.js')?'text/javascript':path.endsWith('.css')?'text/css':'text/html';
          res.writeHead(200,{'Content-Type':mime+'; charset=utf-8'});return res.end(readFileSync(resolve(root,files[path])));
        }
        return json(res,404,{error:'Not found'});
      }
      if(req.method!=='POST') return json(res,405,{error:'Method not allowed'});
      const origin=req.headers.origin;
      if(origin && origin!=='http://'+host) return json(res,403,{error:'Cross-origin request blocked'});
      const sent=Buffer.from(req.headers['x-node-token']||'');
      if(sent.length!==token.length || !timingSafeEqual(sent,Buffer.from(token))) return json(res,403,{error:'Missing or invalid node token'});
      if(!req.headers['content-type']?.startsWith('application/json')) return json(res,415,{error:'Use application/json'});
      const key=req.socket.remoteAddress, now=Date.now(), c=counts.get(key)||{time:now,n:0};
      if(now-c.time>60000) {c.time=now;c.n=0;} c.n++; counts.set(key,c);
      if(c.n>120) return json(res,429,{error:'Too many requests. Wait one minute.'});
      let body=''; for await(const chunk of req) {body+=chunk; if(Buffer.byteLength(body)>32768) {json(res,413,{error:'Request too large'});return;}}
      const data=JSON.parse(body||'{}');
      if(path==='/api/transactions') return json(res,201,{id:chain.submit(data),status:'pending'});
      if(path==='/api/mine') return json(res,201,{block:chain.mine(data.address)});
      if(path==='/api/sync') {
        if(!Number.isInteger(data.peer)||!peers[data.peer]) throw new Error('Select a configured peer');
        const response=await fetch(peers[data.peer]+'/api/chain',{signal:AbortSignal.timeout(10000),redirect:'error'});
        if(!response.ok) throw new Error('Peer unavailable');
        let text=''; for await(const chunk of response.body) {text+=Buffer.from(chunk).toString();if(text.length>16_000_000) throw new Error('Peer response too large');}
        const remote=JSON.parse(text); chain.adopt(remote.blocks); return json(res,200,{height:chain.blocks.length-1});
      }
      return json(res,404,{error:'Not found'});
    } catch(e) {if(!res.headersSent) json(res,400,{error:e.message});else res.end();}
  });
  server.requestTimeout=15000; server.headersTimeout=10000;
  return {server,chain};
}
if(process.argv[1] && resolve(process.argv[1])===fileURLToPath(import.meta.url)) {
  const port=Number(process.env.PORT||3000), file=resolve(process.env.DATA_FILE||'data/chain.json');
  const peers=(process.env.PEERS||'').split(',').filter(Boolean).map(s=>{
    const u=new URL(s); if(u.protocol!=='http:' || !['localhost','127.0.0.1','[::1]'].includes(u.hostname) || u.pathname!=='/' || u.username || u.password || u.search || u.hash) throw new Error('PEERS must contain loopback HTTP origins');
    return u.origin;
  });
  const {server}=createNode({file,peers});
  server.listen(port,'127.0.0.1',()=>console.log(`SuCoin local network: http://localhost:${port}\nData: ${file}\nTest assets only. Ctrl+C to stop.`));
}
