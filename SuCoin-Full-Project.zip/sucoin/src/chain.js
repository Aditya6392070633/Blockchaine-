import { createHash, createPublicKey, verify } from 'node:crypto';
import { existsSync, readFileSync, mkdirSync, writeFileSync, renameSync, openSync, fsyncSync, closeSync } from 'node:fs';
import { dirname } from 'node:path';
export const NETWORK = 'sucoin-local-v1';
export const SCALE = 1_000_000;
export const DIFFICULTY = 3;
export const MAX_BLOCKS = 5000; // Explicit resource bound for this local prototype.
const MAX = 21_000_000 * SCALE;
export function canonical(v) {
  if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
  if (v !== null && typeof v === 'object') return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
  return JSON.stringify(v);
}
export const hash = value => createHash('sha256').update(typeof value === 'string' ? value : canonical(value)).digest('hex');
export const address = pub => 'su' + hash(Buffer.from(pub, 'base64').toString('hex')).slice(0,40);
export const validAddress = a => typeof a === 'string' && /^su[0-9a-f]{40}$/.test(a);
function check(ok, message) { if (!ok) throw new Error(message); }
function exact(v, keys) { check(v && typeof v === 'object' && !Array.isArray(v) && Object.keys(v).sort().join() === [...keys].sort().join(), 'Unexpected or missing fields'); }
function int(n, min=1, max=MAX) { check(Number.isSafeInteger(n) && n >= min && n <= max, 'Invalid integer amount or nonce'); }
export function unsigned(tx) { const {signature, id, ...body} = tx; return body; }
export function validateTx(tx) {
  exact(tx, ['network','publicKey','from','nonce','type','data','signature','id']);
  check(tx.network === NETWORK, 'Wrong network');
  check(typeof tx.publicKey === 'string' && tx.publicKey.length <= 200, 'Invalid public key');
  check(validAddress(tx.from) && tx.from === address(tx.publicKey), 'Sender does not match public key');
  int(tx.nonce); check(typeof tx.signature === 'string' && /^[0-9a-f]{128}$/.test(tx.signature), 'Invalid signature format');
  const key = createPublicKey({key: Buffer.from(tx.publicKey, 'base64'), format:'der',type:'spki'});
  check(key.asymmetricKeyType === 'ec' && key.asymmetricKeyDetails?.namedCurve === 'prime256v1', 'Only P-256 keys accepted');
  check(key.export({format:'der',type:'spki'}).toString('base64') === tx.publicKey, 'Non-canonical public key');
  check(tx.id === hash(unsigned(tx)), 'Transaction ID mismatch');
  check(verify('sha256', Buffer.from(canonical(unsigned(tx))), {key,dsaEncoding:'ieee-p1363'}, Buffer.from(tx.signature,'hex')), 'Invalid signature');
}
export const emptyState = () => ({accounts:{}, orders:[], trades:[], supply:0});
export function account(state, a) { return state.accounts[a] ??= {suc:0, usd:0, lockedSuc:0, lockedUsd:0, nonce:0, faucet:false}; }
const cost = (qty, price) => { const n = BigInt(qty)*BigInt(price)/BigInt(SCALE); check(n <= BigInt(MAX), 'Order value too large'); return Number(n); };
export function apply(state, tx) {
  validateTx(tx);
  const a = account(state,tx.from), d = tx.data;
  check(tx.nonce === a.nonce + 1, 'Invalid nonce: refresh wallet');
  if(tx.type === 'transfer') {
    exact(d,['to','amount']); check(validAddress(d.to), 'Invalid recipient'); int(d.amount);
    check(a.suc >= d.amount, 'Insufficient SUC'); a.suc -= d.amount; account(state,d.to).suc += d.amount;
  } else if(tx.type === 'faucet') {
    exact(d,[]); check(!a.faucet,'Test dollars already claimed'); a.usd += 10_000*SCALE; a.faucet=true;
  } else if(tx.type === 'order') {
    exact(d,['side','quantity','price']); check(['buy','sell'].includes(d.side),'Invalid order side');
    int(d.quantity); int(d.price); check(d.quantity % 1000 === 0 && d.price % 1000 === 0, 'Quantity and price must use 0.001 increments');
    const total = cost(d.quantity,d.price);
    if(d.side === 'buy') { check(a.usd >= total,'Insufficient test dollars'); a.usd-=total; a.lockedUsd+=total; }
    else { check(a.suc >= d.quantity,'Insufficient SUC'); a.suc-=d.quantity; a.lockedSuc+=d.quantity; }
    const incoming = {id:tx.id,owner:tx.from,side:d.side,price:d.price,remaining:d.quantity};
    const matches = state.orders.filter(o => o.side !== incoming.side && (incoming.side === 'buy' ? o.price <= incoming.price : o.price >= incoming.price));
    // Stable sorting retains the chain insertion order at each price level.
    matches.sort((x,y) => incoming.side === 'buy' ? x.price-y.price : y.price-x.price);
    for(const maker of matches) {
      if (!incoming.remaining) break;
      check(maker.owner !== incoming.owner, 'Self-trading is not allowed: cancel your crossing order');
      const qty = Math.min(maker.remaining,incoming.remaining), price=maker.price;
      const buy = incoming.side === 'buy' ? incoming : maker, sell = incoming.side === 'sell' ? incoming : maker;
      const buyer=account(state,buy.owner), seller=account(state,sell.owner), locked=cost(qty,buy.price), paid=cost(qty,price);
      buyer.lockedUsd-=locked; buyer.usd+=locked-paid; buyer.suc+=qty;
      seller.lockedSuc-=qty; seller.usd+=paid;
      maker.remaining-=qty; incoming.remaining-=qty;
      state.trades.push({id:tx.id+':'+state.trades.length,buy:buy.owner,sell:sell.owner,quantity:qty,price});
    }
    state.orders = state.orders.filter(o => o.remaining);
    if(incoming.remaining) state.orders.push(incoming);
  } else if(tx.type === 'cancel') {
    exact(d,['orderId']); const o=state.orders.find(o => o.id===d.orderId);
    check(o && o.owner===tx.from,'Order not found or not owned by you');
    if(o.side==='buy') { const n=cost(o.remaining,o.price); a.usd+=n; a.lockedUsd-=n; }
    else { a.suc+=o.remaining; a.lockedSuc-=o.remaining; }
    state.orders=state.orders.filter(x=>x.id!==o.id);
  } else throw new Error('Unknown transaction type');
  a.nonce=tx.nonce;
}
export const reward = height => Math.floor(50*SCALE / 2 ** Math.floor((height-1)/210000));
export const GENESIS = Object.freeze({network:NETWORK,height:0,previous:'0'.repeat(64),timestamp:0,miner:'genesis',nonce:0,transactions:[],hash:hash('SuCoin local genesis v1')});
export function blockHash(block) { const {hash: ignored,...body}=block; return hash(body); }
export function validateChain(chain) {
  check(Array.isArray(chain) && chain.length>0 && chain.length<=MAX_BLOCKS,'Invalid chain length');
  check(canonical(chain[0])===canonical(GENESIS),'Invalid genesis');
  const state=emptyState();
  for(let i=1;i<chain.length;i++) {
    const b=chain[i], prev=chain[i-1];
    exact(b,['network','height','previous','timestamp','miner','nonce','transactions','hash']);
    check(b.network===NETWORK && b.height===i && b.previous===prev.hash,'Broken block linkage');
    int(b.timestamp,prev.timestamp,Date.now()+120000); int(b.nonce,0,Number.MAX_SAFE_INTEGER);
    check(validAddress(b.miner),'Invalid miner');
    check(Array.isArray(b.transactions) && b.transactions.length<=100,'Invalid block transactions');
    check(b.hash===blockHash(b) && b.hash.startsWith('0'.repeat(DIFFICULTY)),'Invalid proof of work');
    for(const tx of b.transactions) apply(state,tx);
    const n=reward(i); state.supply+=n; account(state,b.miner).suc+=n;
  }
  return state;
}
export class Chain {
  constructor(file=null) {
    this.file=file; this.blocks=[structuredClone(GENESIS)]; this.pending=[]; this.state=emptyState();
    if(file && existsSync(file)) {
      const data=JSON.parse(readFileSync(file,'utf8')); this.state=validateChain(data.blocks); this.blocks=data.blocks;
      check(Array.isArray(data.pending) && data.pending.length<=100,'Invalid saved mempool');
      const overlay=structuredClone(this.state); for(const tx of data.pending) apply(overlay,tx); this.pending=data.pending;
    }
  }
  save(blocks=this.blocks,pending=this.pending) {
    if(!this.file) return;
    mkdirSync(dirname(this.file),{recursive:true}); const temp=this.file+'.tmp';
    writeFileSync(temp,JSON.stringify({blocks,pending}),{mode:0o600});
    const fd=openSync(temp,'r'); try {fsyncSync(fd);} finally {closeSync(fd);}
    renameSync(temp,this.file);
  }
  overlay() { const s=structuredClone(this.state); for(const tx of this.pending) apply(s,tx); return s; }
  submit(tx) {
    check(this.pending.length<100,'Mempool full: mine a block');
    const s=this.overlay(); apply(s,tx); const pending=[...this.pending,structuredClone(tx)];
    this.save(this.blocks,pending); this.pending=pending; return tx.id;
  }
  mine(miner) {
    check(validAddress(miner),'Invalid miner address'); check(this.blocks.length<MAX_BLOCKS,'Local chain limit reached');
    const state=this.overlay(); const prev=this.blocks.at(-1);
    const b={network:NETWORK,height:this.blocks.length,previous:prev.hash,timestamp:Math.max(Date.now(),prev.timestamp),miner,nonce:0,transactions:structuredClone(this.pending)};
    do { b.nonce++; b.hash=blockHash(b); } while(!b.hash.startsWith('0'.repeat(DIFFICULTY)));
    const n=reward(b.height); account(state,miner).suc+=n; state.supply+=n;
    const blocks=[...this.blocks,b]; this.save(blocks,[]); this.blocks=blocks; this.pending=[]; this.state=state; return b;
  }
  adopt(blocks) {
    check(blocks.length>this.blocks.length,'Peer chain is not longer'); const state=validateChain(blocks);
    // Reconsider orphaned transactions and local pending transactions after a reorg.
    const confirmed = new Set(blocks.flatMap(b=>b.transactions.map(t=>t.id)));
    const candidates=[...this.blocks.flatMap(b=>b.transactions),...this.pending].filter(t=>!confirmed.has(t.id));
    const overlay=structuredClone(state), pending=[];
    for(const t of candidates) { if(pending.length>=100) break; const trial=structuredClone(overlay); try {apply(trial,t); Object.assign(overlay,trial); pending.push(t);} catch {} }
    this.save(blocks,pending); this.blocks=structuredClone(blocks); this.state=state; this.pending=pending;
  }
}
