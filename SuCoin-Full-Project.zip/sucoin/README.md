# SuCoin

A complete, runnable **local development project** combining an independent proof-of-work blockchain, encrypted browser wallets, a responsive block explorer, mining controls and an on-chain limit-order exchange.

**All assets are local test assets with no established monetary value.** The exchange pairs SUC with faucet-issued test dollars (`tUSD`), not USD, USDT, Bitcoin or bank deposits. Trades actually change the blockchain state; there are no fabricated balances, market prices or execution confirmations.

## Run in three steps

1. Install Node.js 22 or newer (tested here on Node.js 24.22.1).
2. Extract this folder and open a terminal inside `sucoin` (where `package.json` lives).
3. Run:

```sh
npm start
```

Open **http://localhost:3000**. No API key, database installation, npm installation or build step is needed for the app. The application uses Node built-in modules and browser Web Crypto; it makes no third-party requests.

Optional automated demonstration, in a second terminal:

```sh
npm run demo
```

This creates two encrypted demonstration wallet backups under `data/demo-wallets-<timestamp>/`, mines coins, claims test dollars and matches a real 4-SUC trade. The terminal prints their demo-only password. Import either file through **My wallet** after entering that password. The demo writes to the currently running local chain; it is not just a printed simulation.

## First manual walkthrough

1. Open **My wallet**. Enter a password of at least 12 characters and click **Create wallet**. This is wallet A.
2. Download its **Encrypted backup**. There is no password or private-key recovery service.
3. Open **Network & mining** and click **Mine next block**. A receives 50 SUC.
4. Return to **My wallet**, enter another password and create wallet B. Wallet selection lets you switch between them; switching locks the signing key.
5. As B, open **Exchange**, claim 10,000 test dollars, approve the signing dialog, then mine a block. The faucet works once per address and is deliberately unrestricted across new addresses on this local network.
6. Select A, enter its password and unlock. Place a sell limit order for 10 SUC at 2 tUSD. Mine a block.
7. Select B and unlock it. Place a buy order for 4 SUC with limit price 3 tUSD. Mine a block. It executes at the resting seller's 2-tUSD price: B spends 8 tUSD and receives 4 SUC. A's order retains 6 SUC.
8. Select A and cancel the remaining order. Mine again to release the remaining 6 SUC.
9. To transfer, enter a recipient address and amount in **My wallet**, review, sign and submit. Mine a block to confirm. The mempool reserves pending spends to reject double spending.
10. **Block explorer** searches full block hashes, exact heights, transaction IDs and addresses across the full local chain. Click a block height to inspect its JSON.

Mining issues a fresh block reward to the selected wallet, so balances will also reflect rewards from steps in which you mine. Available and locked balances are confirmed balances; pending reservations are enforced by the server and become visible as confirmed balances after mining.

## What is implemented

| Component | Working behavior |
| --- | --- |
| Blockchain | Deterministic genesis; SHA-256 proof of work; linked blocks; full replay validation; mining rewards and halvings |
| Transactions | Browser P-256 signatures; canonical JSON; network binding; sequential account nonces; integer amounts |
| Wallet | Create multiple wallets, switch, lock, unlock, encrypted export/import, receive address, signed send |
| Encryption | PBKDF2-SHA-256, 250,000 iterations, random salt, AES-256-GCM, random IV; decrypted signing key is non-exportable in memory |
| Exchange | Signed buy/sell limit orders; balance reservation; price-time priority; partial fills; maker-price execution; atomic settlement; cancellation |
| Market views | Actual order book, own open orders, executed trades and trade-price history |
| Explorer | Mempool, latest blocks, full-chain search and block details |
| Storage | JSON file persisted before successful mutations; temporary-file write, fsync and atomic rename; startup chain and mempool validation |
| Nodes | Separate local HTTP nodes; manually requested sync with configured peers; longest valid fixed-difficulty chain; orphan transaction reconsideration |
| Interface | Five responsive views; loading/error states; explicit signing confirmation; accessible form labels and keyboard controls |

**This is not a Bitcoin code fork or Bitcoin-compatible implementation.** Bitcoin uses a different transaction model, signature curve, address format, networking and consensus rules. SuCoin intentionally uses an account ledger and P-256 for native browser signing. There is no Bitcoin mainnet connectivity or wallet compatibility. The six-decimal precision, fixed local difficulty, immediate block rewards and protocol-native test exchange are SuCoin-specific choices.

## Two local nodes

Each process MUST use a different data file. Never point multiple running processes at the same file.

Linux/macOS, terminal 1:

```sh
PORT=3000 DATA_FILE=data/node-a.json PEERS=http://localhost:3001 npm start
```

Terminal 2:

```sh
PORT=3001 DATA_FILE=data/node-b.json PEERS=http://localhost:3000 npm start
```

Windows PowerShell, terminal 1:

```powershell
$env:PORT="3000"
$env:DATA_FILE="data/node-a.json"
$env:PEERS="http://localhost:3001"
npm start
```

Terminal 2:

```powershell
$env:PORT="3001"
$env:DATA_FILE="data/node-b.json"
$env:PEERS="http://localhost:3000"
npm start
```

Create/mine on node A; open node B at `http://localhost:3001`, then **Network & mining → Sync http://localhost:3000**. Nodes verify every block and transaction before adopting a strictly longer chain. Equal-length chains are not adopted. Sync is manually pulled; there is no automatic peer discovery, transaction gossip or background block propagation. Export/import a wallet to use the same identity on another browser origin.

## Tests

```sh
npm test
```

Uses Node's built-in test runner with no dependencies. Covers consensus, transaction signatures, replay/double-spend rejection, order matching/cancellation, integer precision, wallet encryption, persistence, API protection and two-node synchronization. Tests use temporary state and do not change your running node.

Optional browser tests:

```sh
npm install --no-save playwright
npx playwright install chromium
npm run test:browser
```

The browser test starts a separate temporary node and exercises the actual UI: wallet creation, mining, sending, faucet, two-wallet trading, cancelling, backup recovery, errors, explorer and layout at 1440, 768, 390 and 320 CSS pixels. Chromium may require system libraries; its installer will report them. See `docs/TEST_REPORT.md` and the included raw test outputs for actual executed results and limitations.

## Architecture and API

- `src/chain.js`: validation, signatures, mining, account state, exchange, persistence and fork adoption.
- `src/server.js`: HTTP API, loopback binding, local request protection and static app serving.
- `public/wallet.js`: browser cryptography, encrypted wallets and exact decimal parsing.
- `public/app.js`, `index.html`, `style.css`: dependency-free responsive application.
- `src/demo.js`: executable local demo with importable encrypted test wallets.
- `test/`: automated core/API/crypto tests and browser workflow tests.
- `docs/PROTOCOL.md`: transaction format and consensus semantics.
- `docs/SECURITY.md`: trust model and production gaps.

| Endpoint | Method | Result |
| --- | --- | --- |
| `/api/session` | GET | Local mutation token and network name |
| `/api/state?address=su…` | GET | Confirmed and projected wallet state; recent chain, market and mempool |
| `/api/chain` | GET | Full chain for local synchronization |
| `/api/transactions` | POST | Validate and queue signed transaction |
| `/api/mine` | POST | Mine pending transactions; body `{"address":"su…"}` |
| `/api/sync` | POST | Pull configured peer; body `{"peer":0}` |

POST requests require `Content-Type: application/json` and `X-Node-Token` obtained from the session endpoint. Browser requests must be same-origin. The token is local request protection, not an authenticated user account system. Ownership of funds is proved by signed transactions. The browser receives no private keys from the node.

## Data and operations

Default persistent chain file: `data/chain.json`. Stop the node before copying this file for backups. Wallets are encrypted in the browser's local storage; encrypted backup downloads are the portable recovery mechanism. Clearing browser storage without a backup loses that wallet. Keep the password separately. HTTPS or localhost is required by browser Web Crypto; the provided server deliberately binds only to loopback and rejects other hostnames.

The node rejects corrupted state at startup rather than silently resetting it. To create a new clean network, stop the node and use a new `DATA_FILE`; wallet addresses can be reused but have no funds on the new chain. Mempool capacity is 100 transactions; mine to clear it. Blocks contain up to 100 transactions. The local prototype caps total chain length at 5,000 blocks to bound replay cost. API writes are rate-limited per source to 120/minute. Mining is synchronous and low-difficulty, suitable only for a local demo.

## Public launch boundary

This project runs real operations on its own local chain. It is **not ready to hold customer funds, accept real deposits or launch a secure public cryptocurrency**. There is no fiat gateway, external asset bridge, exchange listing, guaranteed liquidity, regulatory onboarding or production custody service. The test-dollar faucet is not a stablecoin.

A public version requires a separate hardened network/consensus implementation, independent security audits, production infrastructure, robust wallet review, service monitoring and any required real-asset integrations. See `docs/SECURITY.md`. Tests demonstrate the listed cases; they are not a security certification or a promise that the software has no defects.
