const enc=new TextEncoder();
export const canonical=v=>Array.isArray(v)?'['+v.map(canonical).join(',')+']':v!==null&&typeof v==='object'?'{'+Object.keys(v).sort().map(k=>JSON.stringify(k)+':'+canonical(v[k])).join(',')+'}':JSON.stringify(v);
const hex=bytes=>Array.from(new Uint8Array(bytes),x=>x.toString(16).padStart(2,'0')).join('');
const b64=bytes=>btoa(String.fromCharCode(...new Uint8Array(bytes)));
const unb64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
const digest=async s=>hex(await crypto.subtle.digest('SHA-256',enc.encode(s)));
export const addressOf=async pub=>'su'+(await digest(hex(unb64(pub)))).slice(0,40);
async function derive(password,salt,usage) {
  const base=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveKey']);
  return crypto.subtle.deriveKey({name:'PBKDF2',salt,iterations:250000,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,usage);
}
export async function createWallet(password) {
  if(password.length<12) throw Error('Use a password of at least 12 characters');
  const pair=await crypto.subtle.generateKey({name:'ECDSA',namedCurve:'P-256'},true,['sign','verify']);
  const publicKey=b64(await crypto.subtle.exportKey('spki',pair.publicKey));
  const privateKey=await crypto.subtle.exportKey('jwk',pair.privateKey);
  const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12));
  const key=await derive(password,salt,['encrypt']);
  const ciphertext=await crypto.subtle.encrypt({name:'AES-GCM',iv},key,enc.encode(JSON.stringify({privateKey,publicKey})));
  return {version:1,address:await addressOf(publicKey),publicKey,salt:b64(salt),iv:b64(iv),ciphertext:b64(ciphertext)};
}
export function validateEnvelope(w) {
  if(!w||w.version!==1||typeof w.address!=='string'||!/^su[0-9a-f]{40}$/.test(w.address)||['publicKey','salt','iv','ciphertext'].some(k=>typeof w[k]!=='string'||w[k].length>4096)) throw Error('Invalid SuCoin wallet file');
  if(unb64(w.salt).length!==16||unb64(w.iv).length!==12) throw Error('Invalid wallet encryption parameters');
}
export async function unlockWallet(w,password) {
  validateEnvelope(w);
  try {
    const key=await derive(password,unb64(w.salt),['decrypt']);
    const plain=await crypto.subtle.decrypt({name:'AES-GCM',iv:unb64(w.iv)},key,unb64(w.ciphertext));
    const data=JSON.parse(new TextDecoder().decode(plain));
    if(data.publicKey!==w.publicKey||await addressOf(w.publicKey)!==w.address) throw Error();
    const privateKey=await crypto.subtle.importKey('jwk',data.privateKey,{name:'ECDSA',namedCurve:'P-256'},false,['sign']);
    const pub=await crypto.subtle.importKey('spki',unb64(w.publicKey),{name:'ECDSA',namedCurve:'P-256'},false,['verify']);
    const proof=await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},privateKey,enc.encode('SuCoin key check'));
    if(!await crypto.subtle.verify({name:'ECDSA',hash:'SHA-256'},pub,proof,enc.encode('SuCoin key check'))) throw Error();
    return privateKey;
  } catch {throw Error('Wrong password or damaged wallet file');}
}
export async function signTransaction(wallet,key,nonce,type,data) {
  const body={network:'sucoin-local-v1',publicKey:wallet.publicKey,from:wallet.address,nonce,type,data};
  const bytes=enc.encode(canonical(body));
  return {...body,id:await digest(canonical(body)),signature:hex(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,bytes))};
}
export function units(text) {
  if(!/^\d+(\.\d{1,6})?$/.test(String(text))) throw Error('Enter a positive number with up to 6 decimal places');
  const [whole,fraction='']=String(text).split('.');
  const n=BigInt(whole)*1000000n+BigInt(fraction.padEnd(6,'0'));
  if(n<=0n||n>21000000000000n) throw Error('Amount out of range'); return Number(n);
}
