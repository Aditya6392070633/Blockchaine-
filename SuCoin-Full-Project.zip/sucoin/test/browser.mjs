import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createNode} from '../src/server.js';
let chromium;
try {({chromium}=await import('playwright'));} catch {if(!process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES)throw Error('Install optional browser testing tools: npm install --no-save playwright; npx playwright install chromium');({chromium}=await import(pathToFileURL(join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES,'playwright/index.mjs')).href));}
const temp=mkdtempSync(join(tmpdir(),'sucoin-browser-'));
const {server,chain}=createNode({file:join(temp,'chain.json')});
await new Promise(r=>server.listen(0,'127.0.0.1',r));
const url='http://127.0.0.1:'+server.address().port;
let browser;let checks=0;
function passed(text){checks++;console.log('PASS '+text);}
try {
 browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_PATH||undefined,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1440,height:1100},acceptDownloads:true});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 const go=async view=>{await page.locator('nav [data-view="'+view+'"]').click();};
 const waitNotice=async text=>{await page.waitForFunction(text=>document.querySelector('#notice').textContent.includes(text),text);};
 const password='SuCoin-test-pass-2026';
 const unlock=async addr=>{await go('wallet');await page.selectOption('#wallet-select',addr);await page.fill('#password',password);await page.click('#unlock-wallet');await waitNotice('Wallet unlocked');};
 const mine=async()=>{await go('node');await page.click('#mine');await waitNotice('mined.');};
 const confirm=async()=>{await page.locator('#confirm-dialog').waitFor({state:'visible'});await page.click('#confirm-yes');await waitNotice('Transaction submitted');};
 await page.goto(url);await go('wallet');await page.fill('#password',password);await page.click('#create-wallet');await waitNotice('Wallet created');const a=await page.textContent('#receive-address');passed('Create encrypted browser wallet');
 await mine();assert.equal(chain.state.accounts[a].suc,50e6);passed('Mine SHA-256 proof of work from UI');
 await go('wallet');await page.fill('#password',password);await page.click('#create-wallet');await waitNotice('Wallet created');const b=await page.textContent('#receive-address');assert.notEqual(a,b);
 await go('trade');await page.click('#faucet');await confirm();await mine();assert.equal(chain.state.accounts[b].usd,10000e6);passed('Create second wallet and claim confirmed test dollars');
 await unlock(a);await page.fill('#recipient',b);await page.fill('#send-amount','2');await page.click('#send-form button');await confirm();await mine();assert.equal(chain.state.accounts[b].suc,52e6);passed('Sign, submit and confirm wallet transfer');
 await go('trade');await page.selectOption('#side','sell');await page.fill('#order-quantity','10');await page.fill('#order-price','2');await page.click('#order-form button');await confirm();await mine();assert.equal(chain.state.accounts[a].lockedSuc,10e6);
 await unlock(b);await go('trade');await page.selectOption('#side','buy');await page.fill('#order-quantity','4');await page.fill('#order-price','3');await page.click('#order-form button');await confirm();await mine();assert.equal(chain.state.trades.length,1);assert.equal(chain.state.accounts[a].lockedSuc,6e6);assert.equal(chain.state.accounts[b].usd,9992e6);passed('Real two-wallet partial order matching and price improvement');
 await unlock(a);await go('trade');await page.locator('#my-orders button').click();await confirm();await mine();assert.equal(chain.state.orders.length,0);assert.equal(chain.state.accounts[a].lockedSuc,0);passed('Cancel order and release funds');
 await go('wallet');await page.fill('#recipient',b);await page.fill('#send-amount','999999');await page.click('#send-form button');await page.locator('#confirm-dialog').waitFor({state:'visible'});await page.click('#confirm-yes');await waitNotice('Insufficient SUC');assert.equal(chain.pending.length,0);passed('Insufficient funds rejected through UI');
 const downloadPromise=page.waitForEvent('download');await page.click('#export-wallet');const download=await downloadPromise;const backup=join(temp,'wallet.json');await download.saveAs(backup);passed('Download encrypted wallet backup');
 await page.click('#lock');await page.fill('#password','wrong password');await page.click('#unlock-wallet');await waitNotice('Wrong password');passed('Locked wallet and wrong-password protection');
 await page.evaluate(()=>localStorage.removeItem('sucoin-wallets'));await page.reload();await go('wallet');await page.fill('#password',password);await page.setInputFiles('#import-wallet',backup);await waitNotice('Wallet imported');assert.equal(await page.textContent('#receive-address'),a);passed('Restore encrypted wallet after clearing local storage');
 await go('explorer');await page.fill('#search','1');await page.locator('#search-results button').waitFor();await page.locator('#search-results button').first().click();await page.locator('#block-detail').waitFor({state:'visible'});assert.match(await page.textContent('#block-detail'),/previous/);passed('Search chain and inspect block details');
 for(const width of [1440,768,390,320]){await page.setViewportSize({width,height:1000});for(const view of ['overview','wallet','trade','explorer','node']){await go(view);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true,view+' overflows '+width);}passed('No page overflow across all five views at '+width+'px');}
 await page.setViewportSize({width:1440,height:1100});await go('overview');await page.screenshot({path:join(temp,'desktop.png'),fullPage:true});
 if(process.env.SCREENSHOT_PATH)await page.screenshot({path:process.env.SCREENSHOT_PATH,fullPage:true});
 assert.deepEqual(errors,[]);passed('No uncaught browser JavaScript errors');
 console.log('\n'+checks+' browser checks passed. Chromium desktop/mobile viewport emulation; not physical device testing.');
}finally{await browser?.close();await new Promise(r=>{server.closeAllConnections();server.close(r);});rmSync(temp,{recursive:true,force:true});}
