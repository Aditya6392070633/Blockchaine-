import {generateKeyPairSync,sign} from 'node:crypto';
import {address,hash,canonical,NETWORK} from '../src/chain.js';
export function wallet(){const {publicKey,privateKey}=generateKeyPairSync('ec',{namedCurve:'prime256v1'});const pub=publicKey.export({type:'spki',format:'der'}).toString('base64');return {publicKey:pub,privateKey,address:address(pub)};}
export function tx(w,nonce,type,data={}){const body={network:NETWORK,publicKey:w.publicKey,from:w.address,nonce,type,data};return {...body,id:hash(body),signature:sign('sha256',Buffer.from(canonical(body)),{key:w.privateKey,dsaEncoding:'ieee-p1363'}).toString('hex')};}
