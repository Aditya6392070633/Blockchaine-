import test from 'node:test';
import assert from 'node:assert/strict';
import {createWallet,unlockWallet,signTransaction,units} from '../public/wallet.js';
import {validateTx} from '../src/chain.js';
test('browser Web Crypto signatures verify in Node chain engine',async()=>{const w=await createWallet('test-password-123');const key=await unlockWallet(w,'test-password-123');validateTx(await signTransaction(w,key,1,'faucet',{}));assert.equal(key.extractable,false);assert.ok(!JSON.stringify(w).includes('privateKey'));});
test('encrypted wallet rejects wrong password and tampered metadata',async()=>{const w=await createWallet('test-password-123');await assert.rejects(unlockWallet(w,'wrong'),/Wrong password/);w.address='su'+'a'.repeat(40);await assert.rejects(unlockWallet(w,'test-password-123'),/damaged/);});
test('wallet passwords must be at least 12 characters',async()=>{await assert.rejects(createWallet('short'),/12 characters/);});
test('amount parser uses exact decimal arithmetic',()=>{assert.equal(units('0.000001'),1);assert.equal(units('1.234567'),1234567);for(const n of ['1e3','-1','0','0.0000001','NaN','1.','999999999999999999999'])assert.throws(()=>units(n));});
