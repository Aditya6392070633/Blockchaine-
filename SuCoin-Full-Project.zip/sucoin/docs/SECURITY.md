# Security boundary

This is educational local-network software, not audited financial infrastructure.

## Implemented controls

- P-256 signature verification, public-key binding, network domain separation and sequential nonces.
- Exact action schemas and safe integer bounds; integer arithmetic for exchange settlement.
- Pending-state validation prevents repeated pending spends and nonce reuse.
- Every imported chain is replayed and proof of work rechecked before adoption.
- State saved before successful in-memory commit; atomic replacement protects against partial JSON writes. This is not a transactional database or full power-loss durability guarantee.
- Private keys generated and encrypted locally with browser Web Crypto. The server never receives the private key or wallet password.
- Encrypted exports, import key-consistency checks, signing confirmation and 10-minute signing-key timeout. Switching wallets and explicit locking discard the active key reference.
- Loopback-only listener and accepted Host values; same-origin POST checking; local mutation token; no CORS; CSP without inline scripts; request size/time/rate limits.
- User-controlled data rendered with DOM text methods rather than injected HTML.
- Sync targets are configured by the operator at startup and limited to loopback HTTP origins. Redirects are refused.

## Known limitations

- Very low, fixed mining difficulty can be trivially overpowered; any local miner can rewrite history with a longer chain. A malicious local process can also access local endpoints. Do not equate this token or localhost binding with a secure custody boundary.
- No difficulty adjustment, hash-rate security, coinbase maturity, fee market, UTXOs, multisignature, Bitcoin Script, real P2P gossip or automatic peer discovery.
- Synchronous mining and full-chain/full-mempool replay are not designed for throughput. Hard chain, request and mempool limits constrain the demo but do not establish resistance to hostile public traffic.
- No process-level lock on the JSON data file: exactly one node per data file. No replication, concurrent-writer support, database migrations or disaster recovery service.
- Local storage is not a hardware wallet. Browser extensions, device compromise, phishing, XSS or weak passwords could expose keys. Decrypted keys remain in process memory while unlocked; JavaScript cannot guarantee secure memory erasure.
- Backup import/export and password recovery are user-managed. No BIP-39 seed phrase, hardware-wallet compatibility or password reset. Losing the encrypted backup or password can permanently lose access.
- Custom addresses have no checksum and do not verify recipient ownership. A correctly formed address can still be the wrong recipient. Review it carefully.
- Test dollars have unlimited aggregate faucet issuance across freely created addresses. They have no reserve, redemption or relationship to actual dollars. Market prices are only local test executions.
- No fiat payments, custodial deposits/withdrawals, real stablecoin bridge, exchange API integration, user KYC, fraud controls or production account service.
- No external independent audit, adversarial fuzzing campaign, sustained-load test, public network test, physical-device browser test or economic/security proof has been performed.
- The browser can lose connection or receive a nonce conflict if another tab uses the same wallet; refresh and review state before resubmitting. A queued transaction can be dropped during a chain reorganization.

For a public product, treat this as a prototype to inform requirements. Do not expose it unchanged, add real money to it, or advertise it as equivalent to Bitcoin's security.
