# SuCoin local protocol v1

## Identity and signatures

Network ID: `sucoin-local-v1`. P-256 ECDSA keys use the standard DER SPKI public-key encoding, represented in canonical base64. The address is `su` plus the first 40 hexadecimal digits of SHA-256 over the public-key DER bytes represented as a lowercase hexadecimal **string**. This custom address convention has no checksum and is not compatible with Bitcoin.

A transaction has exactly these fields:

```json
{
  "network": "sucoin-local-v1",
  "publicKey": "<base64 DER SPKI>",
  "from": "su<40 lowercase hex characters>",
  "nonce": 1,
  "type": "transfer",
  "data": {"to": "su<40 lowercase hex characters>", "amount": 1000000},
  "id": "<SHA-256 of canonical unsigned body>",
  "signature": "<128 lowercase hex characters: IEEE-P1363 r || s>"
}
```

Canonical JSON recursively sorts object keys and preserves array order. The unsigned body excludes `id` and `signature`. ECDSA signs its UTF-8 encoding with SHA-256. Transaction IDs deliberately exclude the signature, so alternate valid signature encodings cannot create new logical transactions. Public-key/address agreement, exact schemas, network, integer nonce and signature are validated. A sender's next nonce must equal their current account nonce plus one; the mempool overlay includes accepted pending nonces and reservations.

Amounts are integer micro-SUC or micro-tUSD: 1 unit of currency = 1,000,000 atomic units. Inputs must be positive safe integers no greater than 21,000,000 currency units per amount. That bound is a transaction validation bound, not a promise of current supply or market capitalization. The browser parses decimal strings using BigInt, then emits safe integers.

## Actions

- `transfer`: `{to, amount}` moves available SUC.
- `faucet`: `{}` grants 10,000 tUSD once per address. This is a development-only test asset. New identities are freely creatable; there is no Sybil resistance.
- `order`: `{side: "buy" | "sell", quantity, price}`; both quantity and price must be multiples of 1,000 atomic units (0.001 currency units).
- `cancel`: `{orderId}`; only the order owner can cancel.

Buy orders reserve `quantity * limitPrice / 1,000,000` tUSD; sell orders reserve quantity SUC. BigInt calculates products. Tick sizes guarantee that partial-fill products resolve to exact integer quote units. Matching prioritizes the best opposing price, then chain insertion order. Each match settles at the resting order price. Buy limit-price excess is returned immediately upon matching. Unmatched quantities stay locked. Cancellation returns only the remaining locked balance. Self-crossing orders reject in full; trials occur on cloned state, so failed operations cannot partially settle.

Order IDs equal their creating transaction IDs. Trades become authoritative only when their creating transaction is mined. A reorganization can remove or change an observed trade; there is no guaranteed finality.

## Blocks and mining

Genesis is fixed and contains no allocation. Subsequent blocks contain exactly `network`, `height`, `previous`, `timestamp`, `miner`, `nonce`, `transactions`, `hash`. Their hash is SHA-256 of canonical JSON excluding `hash`; a valid hash starts with `000` in hexadecimal (fixed expected work: 4096 hashes). All preceding linkage and transactions are validated on replay. Nonces and timestamps are safe integers; time is nondecreasing and no more than two minutes ahead of the validating node's clock.

The block first applies ordered transactions, then credits the miner. Reward starts at 50 SUC, halves after each group of 210,000 mined blocks, and rounds down to atomic units. Rewards are immediately spendable in subsequent blocks, with no maturity delay. There are no fees. The development resource cap of 5,000 total blocks means a default run does not reach a halving; the halving formula is unit tested separately.

Fixed difficulty makes a strictly longer valid chain the higher-work chain. Ties retain the current chain. On adoption, valid unconfirmed transactions from orphaned blocks and the local mempool are reconsidered in order. Invalid, already-confirmed or over-capacity candidates are dropped. Nodes pull from configured loopback peers; no public P2P protocol is implemented.

## Reference documentation

The browser and server signature encoding was checked against primary platform documentation:

- https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/sign
- https://nodejs.org/api/crypto.html#cryptoverifyalgorithm-data-key-signature-callback

The project tests interoperability using the actual browser/Web Crypto format and the Node verification path.
