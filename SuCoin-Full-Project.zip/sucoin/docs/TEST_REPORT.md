# SuCoin verification report

Date: 17 November 2026. Runtime: Node.js v24.22.1, Linux.

## Executed result

`npm test`: **37 passed, 0 failed, 0 skipped.** Last run duration: 2.324 seconds. See `unit-test-output.txt` for the unedited successful runner output. Individual mining times vary because proof-of-work nonce searches vary.

| Area | Tests | Verified |
| --- | ---: | --- |
| Chain and exchange | 26 | Genesis, PoW rewards, halving formula, signed transfers, invalid signatures, payload/key/network tampering, nonces, double-spend reservations, input validation, faucet, price/time priority, partial fills, refunds, cancellation ownership, self-trade rejection, insufficient funds, persistence, disk-failure rollback, chain adoption, reorgs, invalid blocks, exact fractional fills |
| HTTP and executable demo | 7 | Full API lifecycle, local token/origin checks, Host protection, error/security responses, request-size limit, two-node sync, demo subprocess and recovery of its encrypted wallets |
| Wallet crypto and amounts | 4 | Web Crypto/Node signature interoperability, non-exportable unlocked signing keys, wrong-password/metadata rejection, minimum password length, exact decimal parsing |

The two-node test runs two actual independent HTTP listeners with separate chain objects and verifies the resulting complete state. The demo test runs `src/demo.js` as a child process against an actual local HTTP node, then checks its trade, remaining order and encrypted exported wallets. Persistence tests use real temporary files, reload after mining and reject a corrupted stored chain.

## Browser testing — not completed

The Playwright suite is included at `test/browser.mjs`, but **no browser test case completed in this environment**. The initial Playwright-managed Chromium binary was not installed. An attempt using installed Chromium 156.0.8078.79 was blocked before page load by the environment's prohibition on Unix-domain socket creation (`socket() failed: Operation not permitted`). A separate remote-browser attempt could not reach the local development server (`ERR_CONNECTION_REFUSED`).

Therefore the actual browser UI flows, rendered appearance and responsive layout widths are **not verified here**. Their presence in the suite is not a passing result. The responsive CSS has desktop, tablet and mobile breakpoints, but no visual or physical-device claim is made.

To complete those checks on your computer:

```sh
npm install --no-save playwright
npx playwright install chromium
npm run test:browser
```

Or select an already-installed Chromium executable with the `CHROMIUM_PATH` environment variable. On Linux, install browser system dependencies if Playwright requests them.

The included suite is intended to test wallet creation, mining, signed transfers, faucet, partial trading, cancellation, insufficient funds, backup export/restore, password errors, explorer search and all five views at 1440, 768, 390 and 320 CSS pixels. A successful local run will print individual PASS lines. The suite's viewport emulation is not physical-device testing.

## Scope limits

This is functional test evidence for a local development blockchain, not an independent security audit. Public deployment, real money, public peers, sustained load, browser compatibility, hardware wallets and third-party integrations have not been tested. No claim of "fully tested" or Bitcoin-equivalent security is made.
